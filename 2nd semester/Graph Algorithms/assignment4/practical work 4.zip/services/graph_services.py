import copy
import heapq
from collections import deque
from src.domain.graph_data import GraphData


class GraphService:

    def __init__(self, repo, filename):
        self.repo = repo
        self.filename = filename

    def get_vertices_number(self):
        """
        Get the number of vertices in the graph.
        """
        return self.repo.graph.nr_vertices


    def iterate_vertices(self):
        """
        Iterate over vertices in the graph - return the keys = the vertices
        """
        return list(self.repo.graph.out_edges.keys())

    def check_edge(self, start, end):
        """
        Check if the edge exists between 2 vertices
        :param start: start vertex
        :param end: end vertex
        :return: true if edge exists
        """
        for (i,j) in self.repo.graph.costs:
            if i == start and j == end:
                return True
        return False

    def get_in_degree(self, vertex):
        """
        Get the in_degree of a vertex
        :param vertex: the given vertex
        """
        return len(self.repo.graph.in_edges[vertex])

    def get_out_degree(self, vertex):
        """
        Get the out_degree of a vertex
        :param vertex: the given vertex
        """
        return len(self.repo.graph.out_edges[vertex])

    def iterate_outbound(self, vertex):
        """
        Iterate over outbound edges of a vertex
        :param vertex: the given vertex
        """
        return list(self.repo.graph.out_edges[vertex])

    def iterate_inbound(self, vertex):
        """
        Iterate over inbound edges of a vertex
        :param vertex: the given vertex
        """
        return list(self.repo.graph.in_edges[vertex])

    def retrieve_cost(self, start, end):
        """
        Retrieve the cost of a vertex between 2 vertices
        :param start: the start vertex
        :param end: the end vertex
        """
        if not self.check_edge(start, end):
            raise ValueError("The edge does not exist")
        return self.repo.graph.costs[(start, end)]

    def change_cost(self, start, end, new_cost):
        """
        Change the cost of a vertex between 2 vertices
        :param start: the start vertex
        :param end: the end vertex
        :param new_cost: the new cost
        """
        if not self.check_edge(start, end):
            raise ValueError("The edge does not exist")
        self.repo.graph.costs[(start, end)] = new_cost
        self.repo._save_modifications(self.repo.graph, self.filename)

    def add_vertex(self, new_vertex):
        """
        Add a new vertex to the graph.
        :param new_vertex: the new vertex to be added
        """
        if new_vertex != self.repo.graph.nr_vertices:
            raise ValueError("Vertex must be exactly the next available id")

        self.repo.graph.out_edges[new_vertex] = []
        self.repo.graph.in_edges[new_vertex] = []

        self.repo._save_modifications(self.repo.graph, self.filename)

    def add_edge(self, start, end, cost):
        """
        Add a new edge to the graph.
        :param start: the start vertex
        :param end: the end vertex
        :param cost: the edge cost
        """
        if start < 0 or start >= self.repo.graph.nr_vertices:
            raise ValueError("Start vertex does not exist")
        if end < 0 or end >= self.repo.graph.nr_vertices:
            raise ValueError("End vertex does not exist")

        if (start, end) in self.repo.graph.costs:
            raise ValueError("Edge already exists")

        self.repo.graph.costs[(start, end)] = cost
        self.repo.graph.out_edges[start].append(end)
        self.repo.graph.in_edges[end].append(start)

    def remove_vertex(self, vertex):
        """
        Remove a vertex from the graph.
        :param vertex: the given vertex
        """
        if vertex not in self.repo.graph.out_edges:
            raise ValueError("Vertex does not exist")

        # remove all outbound edges
        for neighbor in list(self.repo.graph.out_edges[vertex]):
            del self.repo.graph.costs[(vertex, neighbor)]
            self.repo.graph.in_edges[neighbor].remove(vertex)

        # remove all inbound edges
        for neighbor in list(self.repo.graph.in_edges[vertex]):
            del self.repo.graph.costs[(neighbor, vertex)]
            self.repo.graph.out_edges[neighbor].remove(vertex)

        # remove all inbound outbound lists of the vertex
        del self.repo.graph.out_edges[vertex]
        del self.repo.graph.in_edges[vertex]
        self.normalize_vertices()
        self.repo._save_modifications(self.repo.graph, self.filename)

    def remove_edge(self, start, end):
        """
        Remove an edge from the graph.
        :param start: the start vertex
        :param end: the end vertex
        """
        if not self.check_edge(start, end):
            raise ValueError("The edge does not exist")

        self.repo.remove_dict(start, end)
        self.repo._save_modifications(self.repo.graph, self.filename)

    def copy_graph(self):
        """
        Copy the graph
        """
        #save the current graph state into the modification file
        self.repo._save_modifications(self.repo.graph, self.filename)

        #return a deep copy of the graph
        return copy.deepcopy(self.repo.graph)

    def create_random_graph(self, filename, vertices, edges):
        """
        Create a random graph and save it to a file.
        :param filename: output file
        :param vertices: number of vertices
        :param edges: number of edges
        """
        self.repo._write_random(filename, vertices, edges)


    def lowest_length_path(self, start, end):
        """
        Backwards BFS from end to start to find the lowest length path between two vertices.
        :param start: start vertex
        :param end: end vertex
        :return: the lowest length path
        """
        n = self.repo.graph.nr_vertices
        parent = [-1] * n  #make a list that contains the parent of each node
        visited = [False] * n #a visited list that changes to true for every node that was visited
        q = [end] #queue starting with the end vertex
        visited[end] = True
        q = deque([end])

        while q:
            v = q.popleft() #contains the leftmost element from the queue (and removes it)
            if v == start: #the reached the start vertex
                break

            for u in self.repo.graph.in_edges[v]:
                if not visited[u]:
                    visited[u] = True
                    parent[u] = v
                    q.append(u)

        if not visited[start]:
            raise ValueError("No path exists")

        path = []  #start to go through vertices and reconstruct the path (from start - end)
        v = start
        while v != -1:
            path.append(v)
            v = parent[v]
        return path

    def normalize_vertices(self):
        old = self.repo.graph
        vertices = sorted(old.out_edges.keys())
        mapping = {v: i for i, v in enumerate(vertices)}

        new = GraphData(len(vertices))

        for (s, e), c in old.costs.items():
            ns = mapping[s]
            ne = mapping[e]
            new.out_edges[ns].append(ne)
            new.in_edges[ne].append(ns)
            new.costs[(ns, ne)] = c

        self.repo.graph = new

    def lowest_cost_walk(self, start, end):
        n = self.repo.graph.nr_vertices
        INF = 10 ** 12

        # d[v][k] = min cost to reach v with k edges
        d = [[INF] * (n + 1) for i in range(n)]
        parent = [[-1] * (n + 1) for i in range(n)]

        d[start][0] = 0 #default (from start to itself with len 0 => cost is 0)

        # fill the DP table up to length n-1 -> longest walk wout negative cycle = n-1
        for k in range(1, n):
            for (u, v), cost in self.repo.graph.costs.items():
                if d[u][k - 1] != INF:
                    #check if by adding the current cost to the total cost computed for k-1 edges i obtain a better cost
                    if d[u][k - 1] + cost < d[v][k]:
                        d[v][k] = d[u][k - 1] + cost
                        parent[v][k] = u

        # best cost to any vertex within n-1 edges
        min_costs = [min(d[v][k] for k in range(n)) for v in range(n)]

        # check for negative cycles (if the nth iteration can be improved)
        for (u, v), cost in self.repo.graph.costs.items():
            # check that using u (at any length < n) + this edge improves best cost for v
            for k_prev in range(n):
                if d[u][k_prev] != INF:
                    if d[u][k_prev] + cost < min_costs[v]:
                        raise ValueError("Negative cost cycle reachable from start vertex")

        # best k for the target vertex
        best_cost = INF
        best_k = -1
        for k in range(n):
            if d[end][k] < best_cost:
                best_cost = d[end][k]
                best_k = k

        if best_cost == INF:
            raise ValueError("No walk exists from start to end")

        #reconstruct path
        path = []
        curr = end
        curr_k = best_k
        while curr_k >= 0:
            path.append(curr)
            curr = parent[curr][curr_k]
            curr_k -= 1

        return path, best_cost


    def prim_mst(self, start):
        n = self.repo.graph.nr_vertices
        edges = self.repo.graph.costs

        #transform into undirected graph
        adj = [[] for i in range(n)]
        for (u,v), cost in edges.items():
            #automatically link both vertices to eachother
            adj[u].append((v,cost))
            adj[v].append((u,cost))

        visited = [False] * n #for nodes that are already in the minimal spanning tree
        mst_edges = [] #list of edges in the mst (parent, node, cost)
        total_cost = 0

        pq = [(0, start, -1)]  #priority queue - list of tuples : (cost, node, parent)
        #starts at given node with no parent(-1) and cost= 0
        #priority queue gives the smallest cost first

        while pq:
            cost, node, parent = heapq.heappop(pq) #take out the min cost tuple
            if visited[node]: #if it was visited move on to the next
                continue

            visited[node] = True #mark current node as visited

            #if this is not the starting node in the mst - record the mst edge
            if parent != -1:
                mst_edges.append((parent, node, cost))
                total_cost += cost

            #push all edges starting from the current node to the pq (any neighbours of the node not yet visited)
            #again the pq will sort them regarding the lowest cost
            for neighbour, c in adj[node]:
                if not visited[neighbour]:
                    heapq.heappush(pq, (c, neighbour, node)) #push into the pq and it sorts it

        if not all(visited):
            raise ValueError("Graph is not connected — MST does not exist")

        return mst_edges, total_cost
