from src.repository.graph_repo import GraphRepo
from src.services.graph_services import GraphService

class GraphUI:

    def __init__(self):
        self.service = None

    def start(self):
        print("GRAPH PROGRAM")

        print("1. Load graph from file")
        print("2. Generate random graph")

        choice = input("> ")

        if choice == "1":
            self.load_graph()

        elif choice == "2":
            self.generate_graph()

        else:
            print("Invalid option")

        if self.service:
            self.menu()

    def load_graph(self):

        filename = input("File to load graph from: ")
        modif_file = input("File to save modifications: ")

        repo = GraphRepo(filename)
        self.service = GraphService(repo, modif_file)
        self.service.normalize_vertices()
        repo._save_modifications(repo.graph, modif_file)

        print("Graph loaded!")


    def generate_graph(self):
        try:
            vertices = int(input("Number of vertices: "))
            ans = input("Do you want to specify number of edges? (y/n): ")

            if ans == "y":
                edges = int(input("Number of edges: "))
            else:
                edges = None

            filename = input("Where to save the generated graph: ")
            modif_file = input("Where to save modifications: ")

            repo = GraphRepo.__new__(GraphRepo)
            repo._write_random(filename, vertices, edges)

            repo = GraphRepo(filename)
            self.service = GraphService(repo, modif_file)

            print("Random graph created!")
        except ValueError as e:
            print(e)

    def print_graph_structure(self):
        """
        Print internal dictionaries
        """
        graph = self.service.repo.graph

        print("\nOUT EDGES:")
        for v in graph.out_edges:
            print(f"{v} -> {graph.out_edges[v]}")

        print("\nIN EDGES:")
        for v in graph.in_edges:
            print(f"{v} <- {graph.in_edges[v]}")

        print("\nCOSTS:")
        for (start, end), cost in graph.costs.items():
            print(f"({start}, {end}) : {cost}")


    def menu(self):

        while True:

            print("\nMENU")
            print("1 number of vertices")
            print("2 iterate vertices")
            print("3 check edge")
            print("4 in degree")
            print("5 out degree")
            print("6 iterate outbound")
            print("7 iterate inbound")
            print("8 add vertex")
            print("9 add edge")
            print("10 remove vertex")
            print("11 remove edge")
            print("12 change cost")
            print("13 retrieve cost")
            print("14 copy graph")
            print("15 print dictionaries")
            print("16 lowest length path between 2 vertices : backwards BFS")
            print("17 lowest cost walk between 2 vertices")
            print("18 construct minimum spanning tree : Prim")
            print("19 vertex coloring with minimum number of colors")
            print("0 exit")

            cmd = input("> ")

            try:

                if cmd == "1":
                    print(self.service.get_vertices_number())

                elif cmd == "2":
                    print(self.service.iterate_vertices())

                elif cmd == "3":
                    s = int(input("start: "))
                    e = int(input("end: "))
                    print(self.service.check_edge(s, e))

                elif cmd == "4":
                    v = int(input("vertex: "))
                    print(self.service.get_in_degree(v))

                elif cmd == "5":
                    v = int(input("vertex: "))
                    print(self.service.get_out_degree(v))

                elif cmd == "6":
                    v = int(input("vertex: "))
                    print(self.service.iterate_outbound(v))

                elif cmd == "7":
                    v = int(input("vertex: "))
                    print(self.service.iterate_inbound(v))

                elif cmd == "8":
                    v = int(input("new vertex id: "))
                    self.service.add_vertex(v)

                elif cmd == "9":
                    s = int(input("start: "))
                    e = int(input("end: "))
                    c = int(input("cost: "))
                    self.service.add_edge(s, e, c)

                elif cmd == "10":
                    v = int(input("vertex: "))
                    self.service.remove_vertex(v)

                elif cmd == "11":
                    s = int(input("start: "))
                    e = int(input("end: "))
                    self.service.remove_edge(s, e)

                elif cmd == "12":
                    s = int(input("start: "))
                    e = int(input("end: "))
                    c = int(input("new cost: "))
                    self.service.change_cost(s, e, c)

                elif cmd == "13":
                    s = int(input("start: "))
                    e = int(input("end: "))
                    c = self.service.retrieve_cost(s, e)
                    print(f"Cost: {c}")

                elif cmd == "14":
                    copy = self.service.copy_graph()
                    print("Graph copied!")

                elif cmd == "15":
                    self.print_graph_structure()

                elif cmd == "16":
                    s = int(input("start: "))
                    e = int(input("end: "))
                    path = self.service.lowest_length_path(s, e)
                    print(path)
                    print(f"length: {len(path)-1}")

                elif cmd == "17":
                    s = int(input("start: "))
                    t = int(input("end: "))
                    path, cost = self.service.lowest_cost_walk(s, t)

                    print("lowest cost walk: ", path)
                    print("cost: ", cost)

                elif cmd == "18":
                    start = int(input("start:"))
                    mst_edges, total_cost = self.service.prim_mst(start)

                    print("minimum spanning tree edges:")
                    for u, v, cost in mst_edges:
                        print(f"{u} -> {v}  (cost {cost})")

                    print(f"total cost of MST: {total_cost}")

                elif cmd == "19":
                    coloring, k = self.service.vertex_coloring()
                    print("the coloring: ")
                    for v, c in coloring.items():
                        print(f"{v} -> color {c}")
                    print("minimum number of colors needed: ", k)

                elif cmd == "0":
                    break

                else:
                    print("Invalid command")

            except Exception as e:
                print("Error:", e)