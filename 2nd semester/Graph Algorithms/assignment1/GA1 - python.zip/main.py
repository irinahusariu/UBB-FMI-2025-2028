from src.console.ui import GraphUI

def main():
    ui = GraphUI()
    ui.start()


if __name__ == "__main__":
    main()
