import copy

class GraphService:

    def __init__(self, repo, filename):
        self.repo = repo
        self.filename = filename

    def get_vertices_number(self):
        """
        Get the number of vertices in the graph.
        """
        return self.repo.graph.nr_vertices


    def iterate_vertices(self):
        """
        Iterate over vertices in the graph - return the keys = the vertices
        """
        return list(self.repo.graph.out_edges.keys())

    def check_edge(self, start, end):
        """
        Check if the edge exists between 2 vertices
        :param start: start vertex
        :param end: end vertex
        :return: true if edge exists
        """
        for (i,j) in self.repo.graph.costs:
            if i == start and j == end:
                return True
        return False

    def get_in_degree(self, vertex):
        """
        Get the in_degree of a vertex
        :param vertex: the given vertex
        """
        return len(self.repo.graph.in_edges[vertex])

    def get_out_degree(self, vertex):
        """
        Get the out_degree of a vertex
        :param vertex: the given vertex
        """
        return len(self.repo.graph.out_edges[vertex])

    def iterate_outbound(self, vertex):
        """
        Iterate over outbound edges of a vertex
        :param vertex: the given vertex
        """
        return list(self.repo.graph.out_edges[vertex])

    def iterate_inbound(self, vertex):
        """
        Iterate over inbound edges of a vertex
        :param vertex: the given vertex
        """
        return list(self.repo.graph.in_edges[vertex])

    def retrieve_cost(self, start, end):
        """
        Retrieve the cost of a vertex between 2 vertices
        :param start: the start vertex
        :param end: the end vertex
        """
        if not self.check_edge(start, end):
            raise ValueError("The edge does not exist")
        return self.repo.graph.costs[(start, end)]

    def change_cost(self, start, end, new_cost):
        """
        Change the cost of a vertex between 2 vertices
        :param start: the start vertex
        :param end: the end vertex
        :param new_cost: the new cost
        """
        if not self.check_edge(start, end):
            raise ValueError("The edge does not exist")
        self.repo.graph.costs[(start, end)] = new_cost
        self.repo._save_modifications(self.repo.graph, self.filename)

    def add_vertex(self, new_vertex):
        """
        Add a new vertex to the graph.
        :param new_vertex: the new vertex to be added
        """
        if new_vertex != self.repo.graph.nr_vertices:
            raise ValueError("Vertex must be exactly the next available id")

        self.repo.graph.out_edges[new_vertex] = []
        self.repo.graph.in_edges[new_vertex] = []

        self.repo._save_modifications(self.repo.graph, self.filename)

    def add_edge(self, start, end, cost):
        """
        Add a new edge to the graph.
        :param start: the start vertex
        :param end: the end vertex
        :param cost: the edge cost
        """
        if start < 0 or start >= self.repo.graph.nr_vertices:
            raise ValueError("Start vertex does not exist")
        if end < 0 or end >= self.repo.graph.nr_vertices:
            raise ValueError("End vertex does not exist")

        if (start, end) in self.repo.graph.costs:
            raise ValueError("Edge already exists")

        self.repo.graph.costs[(start, end)] = cost
        self.repo.graph.out_edges[start].append(end)
        self.repo.graph.in_edges[end].append(start)

    def remove_vertex(self, vertex):
        """
        Remove a vertex from the graph.
        :param vertex: the given vertex
        """
        if vertex not in self.repo.graph.out_edges:
            raise ValueError("Vertex does not exist")

        # remove all outbound edges
        for neighbor in list(self.repo.graph.out_edges[vertex]):
            del self.repo.graph.costs[(vertex, neighbor)]
            self.repo.graph.in_edges[neighbor].remove(vertex)

        # remove all inbound edges
        for neighbor in list(self.repo.graph.in_edges[vertex]):
            del self.repo.graph.costs[(neighbor, vertex)]
            self.repo.graph.out_edges[neighbor].remove(vertex)

        # remove all inbound outbound lists of the vertex
        del self.repo.graph.out_edges[vertex]
        del self.repo.graph.in_edges[vertex]
        self.repo._save_modifications(self.repo.graph, self.filename)

    def remove_edge(self, start, end):
        """
        Remove an edge from the graph.
        :param start: the start vertex
        :param end: the end vertex
        """
        if not self.check_edge(start, end):
            raise ValueError("The edge does not exist")

        self.repo.remove_dict(start, end)
        self.repo._save_modifications(self.repo.graph, self.filename)

    def copy_graph(self):
        """
        Copy the graph
        """
        #save the current graph state into the modification file
        self.repo._save_modifications(self.repo.graph, self.filename)

        #return a deep copy of the graph
        return copy.deepcopy(self.repo.graph)

    def create_random_graph(self, filename, vertices, edges):
        """
        Create a random graph and save it to a file.
        :param filename: output file
        :param vertices: number of vertices
        :param edges: number of edges
        """
        self.repo._write_random(filename, vertices, edges)




