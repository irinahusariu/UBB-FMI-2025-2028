from src.domain.graph_data import GraphData
import random

class GraphRepo:

    def __init__(self, filename):
        self.filename = filename
        self.graph = None
        self._load_file()


    def _load_file(self):
        """
        Reads my graph from file and puts it in self.graph - the graph on which every operation is done
        """
        with open(self.filename) as f:
            first_line = f.readline().strip().split()
            if first_line == "" or len(first_line) > 2:
                raise ValueError("The file is incorrect")
            vertix_no = int(first_line[0])
            edges_no = int(first_line[1])

            self.graph = GraphData(vertix_no)
            for i in range(edges_no):
                line = f.readline().strip().split()
                if line == "" or len(line) != 3:
                    raise ValueError("The file is incorrect")
                start, end, cost = int(line[0]), int(line[1]), int(line[2])
                self.add_dict(self.graph, start, end, cost)



    def add_dict(self, graph, start, end, cost):
        """
        Add a pair of vertices and cost in each dictionary
        :param graph: the specific graph for which i store the data
        :param start: the start vertex
        :param end: the end vertex
        :param cost: the cost
        """
        if start not in range(0, graph.nr_vertices) or end not in range(0, graph.nr_vertices):
            raise ValueError("Invalid vertex pair")
        if (start, end) in graph.costs:
            raise ValueError("The vertex pair already exists")

        graph.out_edges[start].append(end)
        graph.in_edges[end].append(start)
        graph.costs[(start, end)] = cost

    def remove_dict(self, graph, start, end):
        """
        Remove a pair of vertices and cost in each dictionary
        :param graph: the specific graph for which i store the data
        :param start: the start vertex
        :param end: the end vertex
        """
        if start not in range(0, graph.nr_vertices) or end not in range(0, graph.nr_vertices):
            raise ValueError("Invalid vertex pair")
        if (start, end) not in graph.costs:
            raise ValueError("The vertex pair does not exist")
        del graph.costs[(start, end)]
        graph.out_edges[start].remove(end)
        graph.in_edges[end].remove(start)

    def _write_random(self, filename, no_vertix, no_edges = None):
        """
        Write random graph in a file
        :param filename: the file where i save it
        """
        new_graph = GraphData(no_vertix)
        if no_edges is None:
            # choose a reasonable amount of edges randomly
            no_edges = random.randint(0, no_vertix * no_vertix)
        max_edges = no_vertix * no_vertix  # allow self-loops
        if no_edges > max_edges:
            raise ValueError(f"Too many edges requested: {no_edges}. Maximum possible for {no_vertix} vertices is {max_edges}")
        added_edges = 0
        with open(filename, "w") as f:
            f.write(f"{no_vertix} {no_edges}\n")

            while added_edges < no_edges:
                start = random.randint(0, new_graph.nr_vertices - 1)
                end = random.randint(0, new_graph.nr_vertices - 1)
                cost = random.randint(-20, 20)

                if (start, end) in new_graph.costs:
                    continue

                self.add_dict(new_graph, start, end, cost)

                f.write(f"{start} {end} {cost}\n")
                added_edges += 1

    def _save_modifications(self, graph, filename):
        """
        Save graph to a modified file
        :param graph: the specific graph
        :param filename: the file where to save
        """
        no_vertix = graph.nr_vertices
        no_edges = graph.nr_edges
        with open(filename, "w") as f:
            f.write(f"{no_vertix} {no_edges}\n")

            for (start, end), cost in graph.costs.items():
                f.write(f"{start} {end} {cost}\n")

