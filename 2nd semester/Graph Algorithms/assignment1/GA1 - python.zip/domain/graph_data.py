class GraphData:

    def __init__(self, nr_vertices):
        self._nr_vertices = nr_vertices
        self._in_edges = {}
        self._out_edges = {}
        self._costs = {}

        # for each vertix i have an empty list - will be filled with other vertices that have a relation
        for v in range(nr_vertices): #each vertix has a in and out list
            self._in_edges[v] = []
            self._out_edges[v] = []

    @property
    def nr_vertices(self):
        return len(self.out_edges)

    @property
    def nr_edges(self):
        return len(self._costs)

    @property
    def in_edges(self):
        return self._in_edges

    @property
    def out_edges(self):
        return self._out_edges

    @property
    def costs(self):
        return self._costs

    def copy(self):
        new_graph = GraphData(self.nr_vertices, 0)

        for v in self._out_edges:
            new_graph._out_edges[v] = list(self._out_edges[v])
            new_graph._in_edges[v] = list(self._in_edges[v])

        new_graph._costs = dict(self._costs)

        return new_graph
