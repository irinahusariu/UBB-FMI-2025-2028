#include "GraphService.h"
#include <stdexcept>

//constructor of services
GraphService::GraphService(GraphRepo& repo, const string& modFile)
    : repo(repo), modFile(modFile) {
}

//no vertices
int GraphService::getVerticesNumber() const {
    return repo.graph.nrVertices();
}

//iterate through all vertices 
vector<int> GraphService::iterateVertices() const {
    //create a vector for all vertices (copy)
    vector<int> v;
    v.reserve(repo.graph.nrVertices());

    //adds from out edges the keys -> all vertices 
    for (auto& kv : repo.graph.outEdges())
        v.push_back(kv.first);

    //sorts them and returns
    sort(v.begin(), v.end());
    return v;
}

//check if edge exists 
bool GraphService::checkEdge(int start, int end) const {
    return repo.graph.costs().count({ start, end });
}

//get in degree of vertex
int GraphService::getInDegree(int v) const {
    return repo.graph.inEdges().at(v).size();
}

//get out degree of vertex
int GraphService::getOutDegree(int v) const {
    return repo.graph.outEdges().at(v).size();
}

//iterate through outbound neighbours of a vertex
vector<int> GraphService::iterateOutbound(int v) const {
    //a new vector => copy
    vector<int> out = repo.graph.outEdges().at(v);
    sort(out.begin(), out.end());
    return out;
}

//iterate through inbound of a vertex
vector<int> GraphService::iterateInbound(int v) const {
    vector<int> in = repo.graph.inEdges().at(v);
    sort(in.begin(), in.end());
    return in;
}

//change cost ofan edge
void GraphService::changeCost(int s, int e, int c) {
    if (!checkEdge(s, e))
        throw runtime_error("The edge does not exist");

    repo.graph.costs()[{s, e}] = c;
    repo.saveModifications(repo.graph, modFile);
}

//get the cost of an edge 
int GraphService::retrieveCost(int s, int e)
{
    if (!checkEdge(s,e))
        throw runtime_error("The edge does not exist");
    int c; 
    c = repo.graph.costs()[{s, e}];
    return c; 
}

//add a vertex
void GraphService::addVertex(int v) {
    //checks if vertex number > no_vertices or already an existing one 
    if (v != repo.graph.nrVertices())
        throw runtime_error("Vertex must be the next available id");
    //new graph - copy
    GraphData newG(v + 1);
    //add to dict
    for (auto& kv : repo.graph.costs()) {
        int s = kv.first.first;
        int e = kv.first.second;
        int c = kv.second;

        newG.outEdges()[s].push_back(e);
        newG.inEdges()[e].push_back(s);
        newG.costs()[{s, e}] = c;
    }

    repo.graph = newG;
    repo.saveModifications(repo.graph, modFile);
}

//add a new edge 
void GraphService::addEdge(int s, int e, int c) {
    //repo function
    repo.addDict(repo.graph, s, e, c);
    repo.saveModifications(repo.graph, modFile);
}

//remove vertex
void GraphService::removeVertex(int v) {
    //removes all occurences of tha vertex
    for (int out : repo.graph.outEdges()[v])
        repo.graph.costs().erase({ v, out });

    for (int in : repo.graph.inEdges()[v])
        repo.graph.costs().erase({ in, v });

    repo.graph.outEdges().erase(v);
    repo.graph.inEdges().erase(v);

    repo.saveModifications(repo.graph, modFile);
}

//remove edge 
void GraphService::removeEdge(int s, int e) {
    //repo function remove 
    repo.removeDict(repo.graph, s, e);
    repo.saveModifications(repo.graph, modFile);
}

GraphData GraphService::copyGraph() const {
    //save the current graph state into the modification file
    repo.saveModifications(repo.graph, modFile);

    //return a deep copy of the graph
    return repo.graph.copy();
}

//getters for dict 
const unordered_map<int, vector<int>>& GraphService::get_in_edges() const {
    return repo.graph.inEdges();
}

const unordered_map<int, vector<int>>& GraphService::get_out_edges() const {
    return repo.graph.outEdges();
}

const map<pair<int, int>, int>& GraphService::get_costs() const {
    return repo.graph.costs();
}
